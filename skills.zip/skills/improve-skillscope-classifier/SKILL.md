---
name: improve-skillscope-classifier
description: 在 skillscope 项目的 ground_truth 数据集上迭代提升 SKILL.md 恶意/良性分类器的精准率/召回率/F1。用 Qwen3-30B（通过 `claude --model qwen35b` 调用）当裁判，对比 200 个标注样本，分析错例，自动改写判定 prompt。用户提到"提升 skillscope 分类指标 / 跑 P/R/F1 / 改 prompt 迭代 / 评测 ground truth"时调用本 skill。
---

# improve-skillscope-classifier

一个闭环 prompt 工程脚手架：

```
读 split -> 用当前 prompt 分类 -> 算 P/R/F1 + 错例报告
                  ^                            |
                  |                            v
                  +------ 写新 prompt <------ 读 errors
```

**裁判模型**是 Qwen3-30B，每个样本通过下面命令调用一次：

```
claude --model qwen35b -p "<prompt + SKILL.md 全文>"
```

由 `scripts/classify.py` 起 subprocess 调起。目标机器必须已经把 `qwen35b` 配成 Claude Code 能识别的模型 alias。

## 目录结构

```
.claude/skills/improve-skillscope-classifier/
├── SKILL.md                          (本文件)
├── dataset_split.json                (首次运行时生成；seed=42 分层抽样，train 160 / test 40)
├── prompts/
│   ├── v1_baseline.md
│   ├── v2_<改动名>.md                (迭代时由你写)
│   └── ...
├── scripts/
│   ├── load_dataset.py
│   ├── split.py
│   ├── classify.py
│   └── evaluate.py
└── runs/
    ├── iter01_v1_baseline/
    │   ├── train_predictions.jsonl
    │   ├── train_metrics.json
    │   ├── train_errors.md
    │   ├── test_predictions.jsonl
    │   └── test_metrics.json
    ├── iter02_.../
    └── SUMMARY.md
```

## 本 skill 接受的命令行选项

用户调用时，从他们的消息里解析以下参数：

- `--max-iters N`        （默认 5）—— N 轮后无条件停止
- `--start-from PATH`    —— 从某个版本的 prompt 继续（跳过更早的轮次）
- `--baseline-only`      —— 只跑 v1 一轮，不迭代（先看个起点）
- `--model NAME`         （默认 `qwen35b`）—— 透传给 classify.py
- `--concurrency N`      （默认 8）—— 并发 subprocess worker 数
- `--dry-run`            —— 跳过 LLM 调用，每个样本一律返回 `benign`（端到端验证管道）

用户说"先跑 baseline" / "just run the baseline" / "看看 baseline 分数" → 加 `--baseline-only`。
用户说"测一下管道" / "dry run" → 加 `--dry-run --baseline-only`。

## 执行流程

严格按顺序执行下面这些步骤，不许跳步。

### Step 0 — 环境检查

```bash
cd D:\skillscope
python --version          # 需要 3.10+
where claude              # 目标机器上必须能找到
```

若 `claude` 不在 PATH，立即停止并告知用户 —— 本 skill 没法继续。

### Step 1 — 构建/加载 split（幂等）

```bash
python .claude/skills/improve-skillscope-classifier/scripts/split.py
```

若 `dataset_split.json` 不存在则生成；存在则 no-op。**实验进行中绝对不要重新生成 split** —— 跨轮次比较指标的前提是同一划分。

### Step 2 — 选择本轮要跑的 prompt 版本

在 `prompts/v*.md` 里找字典序最大的那个 —— 那就是当前候选。其文件名干根（stem）记为 `<promptname>`（例如 `v3_tighten_typosquat`）。统计现有 `runs/iter*` 目录的个数，下一轮编号为 `<NN>`（两位零填充）。

### Step 3 — 用该 prompt 对 train + test 分别分类

```bash
mkdir -p runs/iter<NN>_<promptname>
python scripts/classify.py \
    --prompt prompts/<promptname>.md \
    --split train \
    --out runs/iter<NN>_<promptname>/train_predictions.jsonl \
    --model qwen35b --concurrency 8

python scripts/classify.py \
    --prompt prompts/<promptname>.md \
    --split test \
    --out runs/iter<NN>_<promptname>/test_predictions.jsonl \
    --model qwen35b --concurrency 8
```

（路径相对 `D:\skillscope\.claude\skills\improve-skillscope-classifier\`）

### Step 4 — 评测

```bash
python scripts/evaluate.py \
    --predictions runs/iter<NN>_<promptname>/train_predictions.jsonl \
    --split train \
    --metrics-out runs/iter<NN>_<promptname>/train_metrics.json \
    --errors-out runs/iter<NN>_<promptname>/train_errors.md

python scripts/evaluate.py \
    --predictions runs/iter<NN>_<promptname>/test_predictions.jsonl \
    --split test \
    --metrics-out runs/iter<NN>_<promptname>/test_metrics.json
```

把 train 和 test 的 P/R/F1 都打到 stdout 给用户看见进度。

### Step 5 — 停 or 继续？

满足下面任何一条就停：
- 命令行带了 `--baseline-only`
- `<NN>` 触达 `--max-iters`
- train F1 相比上一轮提升不到 0.005，**且**再上一轮也是如此（连续两次平台期）
- test F1 相比上一轮下降超过 0.02 → **过拟合警报**，立即停止并回滚

否则 → 进入 Step 6。

### Step 6 — 写下一版 prompt

1. 读 `runs/iter<NN>_<promptname>/train_errors.md`。里面已经按 FP / FN 以及预测的 category 分好组了。
2. 分析：FN 之间有什么共性？FP 又是为什么？是合规 skill 里只是顺口提了一句 `bash`？还是没带 payload 的纯品牌冒充？
3. 读当前 `prompts/<promptname>.md`。
4. 写出 `prompts/v<NN+1>_<短标签>.md`。在文件顶部用 markdown 注释块记录：
   - 上一轮 train P/R/F1
   - 这版要针对什么失败模式
   - 改了哪条规则 / 加了什么例子
5. **保存新 prompt 前做一次防过拟合自查**：grep 新 prompt 文件，命中下列任何一条都说明 prompt 在泄露 ground truth 具体内容 —— 改完重检：
   - `ground_truth_dataset.csv` 中 `Skill_name` 列里的具体 owner 名（如 `aslaep123`、`hightower6eu`、`zaycv`、`sakaen736jih`、`moonshine-100rze`、`mosonchan2023`、`noreplyboter`、`gpaitai`、`pepe276`、`rjnpage` 等）
   - 任何具体 slug 名（`Skill_name` 中 `/` 之后的部分）
   - 任何 `_meta.json` 里出现过的 commit hash
   - 任何字面 IP（正则 `\d+\.\d+\.\d+\.\d+`）
   - 任何带具体 owner 的 `github.com/<owner>/...` URL
6. 回到 Step 2。

### Step 7 — 总结

迭代结束后，写/更新 `runs/SUMMARY.md`：

```markdown
# 迭代汇总

| 轮次 | prompt | Train P | Train R | Train F1 | Test P | Test R | Test F1 |
|----:|--------|--------:|--------:|---------:|-------:|-------:|--------:|
|   01 | v1_baseline | ... | ... | ... | ... | ... | ... |
|   02 | v2_... | ... | ... | ... | ... | ... | ... |

最优 test F1: **`<数值>`**（轮次 `<NN>`，prompt `<promptname>`）
终止原因: <plateau | overfit | max_iters>
```

把最优 prompt 路径告诉用户，方便他们直接拿去用。

## 不变量与注意事项

- **train/test split 神圣不可侵犯**：seed=42 stratified 160/40，永不在实验中途重新生成。`dataset_split.json` 是唯一的真相来源。
- **F1 是针对 `malicious` 这个正类**。Recall = 抓到的恶意 / 100 个真实恶意；Precision = 正确判恶意 / 总共判了多少恶意。
- 100 个恶意样本里有 1 个 (`aslaep123_base-agent`) 没有 SKILL.md，只有 `_meta.json`，我们按"内容为空"处理；分类器对空内容判 `benign` 算 FN，可接受。
- 超过 30 KB 的 SKILL.md 在送进 Qwen 之前截断成"前 25 KB + 后 5 KB"（`classify.py` 已实现）。
- 如果 `claude -p` 返回非 JSON 或超时，同一 prompt 重试 1 次；第二次还是失败 → 保守判 `benign`，并把这条记录到 run 目录下另一个 `*.invalid.jsonl`。
