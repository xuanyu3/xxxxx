"""调用 `claude --model qwen35b -p` 对 split 中每个 SKILL.md 做分类。

每次调用都是一个 subprocess。输出写到 predictions.jsonl（每个样本一行）：
{
  "sample_id": "clawhub/<slug>",
  "predicted_label": "malicious" | "benign" | "INVALID",
  "predicted_category": "<某个 category 或 null>",
  "confidence": 0.0,
  "reason": "...",
  "raw_output": "<裁判模型的原始输出，截断后保留>"
}

用法：
  python classify.py \
      --prompt prompts/v1_baseline.md \
      --split train \
      --out runs/iter01_v1_baseline/train_predictions.jsonl \
      [--model qwen35b] [--concurrency 8] [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from load_dataset import load_all, filter_ids

SKILL_DIR = Path(__file__).resolve().parent.parent
SPLIT_PATH = SKILL_DIR / "dataset_split.json"
TIMEOUT_SEC = 90
MAX_RAW_KEEP = 4000


def load_split(name: str) -> set[str]:
    if not SPLIT_PATH.is_file():
        raise FileNotFoundError(f"先跑一下 split.py 生成 {SPLIT_PATH}")
    data = json.loads(SPLIT_PATH.read_text(encoding="utf-8"))
    if name == "all":
        return set(data["train"]) | set(data["test"])
    if name not in {"train", "test"}:
        raise ValueError(f"--split 必须是 train|test|all，收到 {name}")
    return set(data[name])


def build_prompt(prompt_template: str, skill_md_text: str, sample_id: str) -> str:
    return (
        f"{prompt_template.rstrip()}\n\n"
        f"---\nSAMPLE_ID: {sample_id}\nSKILL.md 内容紧接在下方分隔线之后：\n"
        f"---BEGIN SKILL.md---\n{skill_md_text}\n---END SKILL.md---\n"
    )


JSON_RE = re.compile(r"\{[\s\S]*\}")


def _extract_json(raw: str) -> dict | None:
    """在原始输出里找第一个 {...} 块解析；兼容 ```json 围栏。"""
    if not raw:
        return None
    raw = raw.strip()
    if raw.startswith("```"):
        # 去掉 markdown 围栏
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except Exception:
        m = JSON_RE.search(raw)
        if not m:
            return None
        try:
            return json.loads(m.group(0))
        except Exception:
            return None


def _normalize_label(v) -> str:
    if not isinstance(v, str):
        return "INVALID"
    v = v.strip().lower()
    if v in {"malicious", "mal", "bad", "恶意"}:
        return "malicious"
    if v in {"benign", "safe", "ok", "good", "良性"}:
        return "benign"
    return "INVALID"


def call_qwen(prompt: str, model: str) -> tuple[str, str | None]:
    """调用 claude CLI；返回 (原始 stdout, 错误信息或 None)。"""
    try:
        proc = subprocess.run(
            ["claude", "--model", model, "-p", prompt],
            capture_output=True, text=True, timeout=TIMEOUT_SEC,
            encoding="utf-8", errors="replace",
        )
    except subprocess.TimeoutExpired:
        return "", "超时"
    except FileNotFoundError:
        return "", "PATH 中找不到 claude CLI"
    if proc.returncode != 0:
        return proc.stdout or "", f"exit={proc.returncode} stderr={proc.stderr[:300]}"
    return proc.stdout or "", None


def classify_one(row: dict, prompt_template: str, model: str, dry_run: bool) -> dict:
    sample_id = row["sample_id"]
    if dry_run:
        return {
            "sample_id": sample_id,
            "predicted_label": "benign",
            "predicted_category": None,
            "confidence": 0.0,
            "reason": "dry-run",
            "raw_output": "",
            "error": None,
        }
    full_prompt = build_prompt(prompt_template, row["skill_md_text"], sample_id)

    last_err = None
    raw = ""
    for attempt in (1, 2):
        raw, err = call_qwen(full_prompt, model)
        if err is None and raw.strip():
            parsed = _extract_json(raw)
            if parsed is not None:
                lbl = _normalize_label(parsed.get("label"))
                if lbl in {"malicious", "benign"}:
                    return {
                        "sample_id": sample_id,
                        "predicted_label": lbl,
                        "predicted_category": parsed.get("category"),
                        "confidence": parsed.get("confidence"),
                        "reason": (parsed.get("reason") or "")[:500],
                        "raw_output": raw[:MAX_RAW_KEEP],
                        "error": None,
                    }
                last_err = f"无法标准化 label={parsed.get('label')!r}"
            else:
                last_err = "输出中找不到 JSON 对象"
        else:
            last_err = err or "空输出"
        time.sleep(0.5 * attempt)

    return {
        "sample_id": sample_id,
        "predicted_label": "benign",  # 失败时保守判 benign
        "predicted_category": None,
        "confidence": 0.0,
        "reason": "INVALID —— 回退到 benign",
        "raw_output": raw[:MAX_RAW_KEEP],
        "error": last_err,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompt", required=True, help="prompt 文件路径")
    ap.add_argument("--split", required=True, choices=["train", "test", "all"])
    ap.add_argument("--out", required=True, help="predictions.jsonl 输出路径")
    ap.add_argument("--model", default="qwen35b")
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    prompt_path = Path(args.prompt)
    if not prompt_path.is_absolute():
        prompt_path = (Path.cwd() / prompt_path).resolve()
    if not prompt_path.is_file():
        print(f"找不到 prompt 文件：{prompt_path}", file=sys.stderr)
        return 2
    prompt_template = prompt_path.read_text(encoding="utf-8")

    split_ids = load_split(args.split)
    all_rows = load_all()
    rows = filter_ids(all_rows, split_ids)
    if len(rows) != len(split_ids):
        missing = split_ids - {r["sample_id"] for r in rows}
        print(f"split 中存在数据集里找不到的 id：{sorted(missing)[:5]}",
              file=sys.stderr)
        return 2

    out_path = Path(args.out)
    if not out_path.is_absolute():
        out_path = (Path.cwd() / out_path).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    invalid_path = out_path.with_name(out_path.stem + ".invalid.jsonl")

    t0 = time.time()
    results: list[dict] = []
    invalid: list[dict] = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        futs = {
            pool.submit(classify_one, r, prompt_template, args.model, args.dry_run): r
            for r in rows
        }
        done = 0
        for fut in as_completed(futs):
            res = fut.result()
            results.append(res)
            if res.get("error"):
                invalid.append(res)
            done += 1
            if done % 10 == 0 or done == len(rows):
                elapsed = time.time() - t0
                print(f"  已完成 {done}/{len(rows)} "
                      f"({elapsed:.0f}s，{done/max(elapsed,1):.1f}/s)",
                      file=sys.stderr)

    results.sort(key=lambda r: r["sample_id"])
    with out_path.open("w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    if invalid:
        with invalid_path.open("w", encoding="utf-8") as f:
            for r in invalid:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"已写入 {invalid_path}（{len(invalid)} 条无效）", file=sys.stderr)

    print(f"已写入 {out_path}（{len(results)} 条预测，"
          f"用时 {time.time()-t0:.0f}s）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
