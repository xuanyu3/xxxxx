"""针对 malicious 这个正类计算 P/R/F1，并输出错例报告。

输入：
  --predictions runs/.../train_predictions.jsonl
  --split       train | test | all
  --metrics-out runs/.../train_metrics.json
  --errors-out  runs/.../train_errors.md  （可选；不传就不写错例文件）

metrics.json 结构：
{
  "split": "train",
  "n": 160, "n_malicious": 80, "n_benign": 80,
  "tp": ..., "fp": ..., "tn": ..., "fn": ...,
  "precision": 0.x, "recall": 0.x, "f1": 0.x,
  "accuracy": 0.x,
  "invalid_count": 0
}

errors.md 把 FN 和 FP 分组，附上模型给的 reason 和 SKILL.md 开头片段，
方便人类（或者 Claude）做错例分析，不用再去翻 200 个文件。
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

from load_dataset import load_all, filter_ids

SKILL_DIR = Path(__file__).resolve().parent.parent
SPLIT_PATH = SKILL_DIR / "dataset_split.json"

SNIPPET_HEAD = 1200


def load_split(name: str) -> set[str]:
    data = json.loads(SPLIT_PATH.read_text(encoding="utf-8"))
    if name == "all":
        return set(data["train"]) | set(data["test"])
    return set(data[name])


def _safe_div(a: int, b: int) -> float:
    return (a / b) if b else 0.0


def compute_metrics(predictions: list[dict], gt_by_id: dict[str, str]) -> dict:
    tp = fp = tn = fn = 0
    invalid = 0
    for p in predictions:
        gt = gt_by_id.get(p["sample_id"])
        if gt is None:
            continue
        pred = p["predicted_label"]
        if p.get("error"):
            invalid += 1
        if pred == "malicious" and gt == "malicious":
            tp += 1
        elif pred == "malicious" and gt == "benign":
            fp += 1
        elif pred == "benign" and gt == "benign":
            tn += 1
        elif pred == "benign" and gt == "malicious":
            fn += 1
    n = tp + fp + tn + fn
    precision = _safe_div(tp, tp + fp)
    recall = _safe_div(tp, tp + fn)
    f1 = _safe_div(2 * precision * recall, precision + recall) if (precision + recall) else 0.0
    accuracy = _safe_div(tp + tn, n)
    return {
        "n": n,
        "n_malicious": tp + fn,
        "n_benign": fp + tn,
        "tp": tp, "fp": fp, "tn": tn, "fn": fn,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "accuracy": round(accuracy, 4),
        "invalid_count": invalid,
    }


def write_errors_md(
    path: Path, predictions: list[dict], rows_by_id: dict[str, dict],
    split_name: str, metrics: dict,
) -> None:
    fps: list[dict] = []
    fns: list[dict] = []
    for p in predictions:
        row = rows_by_id.get(p["sample_id"])
        if row is None:
            continue
        gt = row["label"]
        pred = p["predicted_label"]
        if pred == "malicious" and gt == "benign":
            fps.append({"p": p, "row": row})
        elif pred == "benign" and gt == "malicious":
            fns.append({"p": p, "row": row})

    fp_by_predcat = defaultdict(list)
    for e in fps:
        fp_by_predcat[str(e["p"].get("predicted_category"))].append(e)

    lines: list[str] = []
    lines.append(f"# `{split_name}` 集错例报告\n")
    lines.append(
        f"P={metrics['precision']}  R={metrics['recall']}  F1={metrics['f1']}  "
        f"TP={metrics['tp']} FP={metrics['fp']} TN={metrics['tn']} FN={metrics['fn']}  "
        f"invalid={metrics['invalid_count']}\n"
    )

    lines.append(f"\n## 漏报 False Negatives ({len(fns)}) —— 把恶意判成了良性\n")
    for e in fns:
        p = e["p"]; row = e["row"]
        snippet = (row["skill_md_text"] or "(SKILL.md 为空)")[:SNIPPET_HEAD]
        snippet = snippet.replace("```", "ʼʼʼ")
        lines.append(f"\n### {p['sample_id']}")
        lines.append(f"- 模型给出的 reason：{p.get('reason')!r}")
        lines.append(f"- 模型给出的 predicted_category：{p.get('predicted_category')!r}")
        lines.append(f"- skill_md_path: `{row['skill_md_path']}`")
        lines.append("- 内容片段：")
        lines.append("```")
        lines.append(snippet)
        lines.append("```")

    lines.append(f"\n## 误报 False Positives ({len(fps)}) —— 把良性判成了恶意\n")
    for predcat, group in sorted(fp_by_predcat.items()):
        lines.append(f"\n### predicted_category = {predcat}（{len(group)} 个）\n")
        for e in group:
            p = e["p"]; row = e["row"]
            snippet = (row["skill_md_text"] or "(SKILL.md 为空)")[:SNIPPET_HEAD]
            snippet = snippet.replace("```", "ʼʼʼ")
            lines.append(f"#### {p['sample_id']}")
            lines.append(f"- 模型给出的 reason：{p.get('reason')!r}")
            lines.append(f"- skill_md_path: `{row['skill_md_path']}`")
            lines.append("- 内容片段：")
            lines.append("```")
            lines.append(snippet)
            lines.append("```\n")

    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--split", required=True, choices=["train", "test", "all"])
    ap.add_argument("--metrics-out", required=True)
    ap.add_argument("--errors-out", default=None)
    args = ap.parse_args()

    pred_path = Path(args.predictions)
    if not pred_path.is_absolute():
        pred_path = (Path.cwd() / pred_path).resolve()
    if not pred_path.is_file():
        print(f"找不到预测文件：{pred_path}", file=sys.stderr)
        return 2

    predictions = [json.loads(line) for line in pred_path.read_text(
        encoding="utf-8").splitlines() if line.strip()]

    split_ids = load_split(args.split)
    all_rows = load_all()
    rows = filter_ids(all_rows, split_ids)
    rows_by_id = {r["sample_id"]: r for r in rows}
    gt_by_id = {r["sample_id"]: r["label"] for r in rows}

    metrics = compute_metrics(predictions, gt_by_id)
    metrics["split"] = args.split

    metrics_path = Path(args.metrics_out)
    if not metrics_path.is_absolute():
        metrics_path = (Path.cwd() / metrics_path).resolve()
    metrics_path.parent.mkdir(parents=True, exist_ok=True)
    metrics_path.write_text(json.dumps(metrics, indent=2, ensure_ascii=False),
                            encoding="utf-8")

    print(
        f"[{args.split}] P={metrics['precision']:.4f}  R={metrics['recall']:.4f}  "
        f"F1={metrics['f1']:.4f}  Acc={metrics['accuracy']:.4f}  "
        f"(TP={metrics['tp']} FP={metrics['fp']} TN={metrics['tn']} "
        f"FN={metrics['fn']} invalid={metrics['invalid_count']})"
    )

    if args.errors_out:
        errors_path = Path(args.errors_out)
        if not errors_path.is_absolute():
            errors_path = (Path.cwd() / errors_path).resolve()
        write_errors_md(errors_path, predictions, rows_by_id, args.split, metrics)
        print(f"已写入 {errors_path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
