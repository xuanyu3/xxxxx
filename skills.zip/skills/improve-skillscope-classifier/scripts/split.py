"""为 skillscope ground truth 生成分层 train/test split。

写出 dataset_split.json（幂等 —— 若已存在则直接退出）。
seed=42，train=160（80 恶意 + 80 良性），test=40（20 恶意 + 20 良性）。

dataset_split.json 结构：
{
  "seed": 42,
  "train": ["clawhub/<slug>", ...],   # 160 个 id
  "test":  ["clawhub/<slug>", ...]    # 40 个 id
}
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path

from load_dataset import load_all

SKILL_DIR = Path(__file__).resolve().parent.parent
SPLIT_PATH = SKILL_DIR / "dataset_split.json"

SEED = 42
N_TEST_PER_CLASS = 20  # -> 每类 train 各 80


def main() -> int:
    if SPLIT_PATH.is_file():
        existing = json.loads(SPLIT_PATH.read_text(encoding="utf-8"))
        print(f"split 已存在：train={len(existing['train'])} "
              f"test={len(existing['test'])} seed={existing['seed']}（跳过）")
        return 0

    rows = load_all()
    mal = sorted([r["sample_id"] for r in rows if r["label"] == "malicious"])
    ben = sorted([r["sample_id"] for r in rows if r["label"] == "benign"])
    if len(mal) != 100 or len(ben) != 100:
        print(f"样本数量异常：恶意={len(mal)} 良性={len(ben)}", file=sys.stderr)
        return 2

    rng = random.Random(SEED)
    rng.shuffle(mal)
    rng.shuffle(ben)

    test = sorted(mal[:N_TEST_PER_CLASS] + ben[:N_TEST_PER_CLASS])
    train = sorted(mal[N_TEST_PER_CLASS:] + ben[N_TEST_PER_CLASS:])

    payload = {"seed": SEED, "train": train, "test": test}
    SPLIT_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False),
                          encoding="utf-8")
    print(f"已写入 {SPLIT_PATH}：train={len(train)} test={len(test)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
