"""加载 skillscope 项目的 ground_truth_dataset。

把 CSV 每一行解析成 (sample_id, label, skill_md_path, skill_md_text)。
- 恶意样本：SKILL.md 直接在 <Ground_truth_path>/ 下
- 良性样本：SKILL.md 在 <Ground_truth_path>/latest_<hash>/ 下

已知有一个恶意样本 (aslaep123_base-agent) 没有 SKILL.md，只有 _meta.json，
此时返回 skill_md_text=""、skill_md_path=None。

作为库使用：
    from load_dataset import load_all
    rows = load_all()
    for r in rows: print(r["sample_id"], r["label"], len(r["skill_md_text"]))
"""
from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable

PROJECT_ROOT = Path(__file__).resolve().parents[4]  # D:\skillscope
DATASET_DIR = PROJECT_ROOT / "ground_truth_dataset"
CSV_PATH = DATASET_DIR / "ground_truth_dataset.csv"

SKILL_MD_TRUNCATE = 30_000   # 字节；超过这个阈值就头尾截断
TRUNC_HEAD = 25_000
TRUNC_TAIL = 5_000


def _find_skill_md(sample_dir: Path) -> Path | None:
    """返回样本目录里的 SKILL.md 路径，找不到就返回 None。

    先看直接子文件 SKILL.md，再扫一层子目录下的 SKILL.md
    （覆盖良性样本 latest_<hash>/SKILL.md 这种嵌套布局）。
    """
    direct = sample_dir / "SKILL.md"
    if direct.is_file():
        return direct
    for child in sorted(sample_dir.iterdir()):
        if child.is_dir():
            nested = child / "SKILL.md"
            if nested.is_file():
                return nested
    return None


def _read_truncated(p: Path) -> str:
    """读取一份 SKILL.md。

    如果文件无法读取（例如被 Windows Defender 隔离），返回空串
    —— 分类器会把它当作空内容处理。
    """
    try:
        raw = p.read_bytes()
    except OSError:
        return ""
    if len(raw) <= SKILL_MD_TRUNCATE:
        return raw.decode("utf-8", errors="replace")
    head = raw[:TRUNC_HEAD].decode("utf-8", errors="replace")
    tail = raw[-TRUNC_TAIL:].decode("utf-8", errors="replace")
    return f"{head}\n\n[... 已截断 {len(raw) - TRUNC_HEAD - TRUNC_TAIL} 字节 ...]\n\n{tail}"


def load_all() -> list[dict]:
    """加载全部 200 行。

    每个 dict 有：sample_id、label ('malicious'|'benign')、registry、
    skill_name、skill_md_path (str 或 None)、skill_md_text (str，可能为空)。
    sample_id 形如 "<registry>/<skill_name>"，全局唯一。
    """
    if not CSV_PATH.is_file():
        raise FileNotFoundError(f"找不到 ground truth CSV：{CSV_PATH}")

    rows: list[dict] = []
    with CSV_PATH.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            label = row["Label"].strip()
            registry = row["Registry"].strip()
            skill_name = row["Skill_name"].strip()
            rel = row["Ground_truth_path"].strip()
            sample_dir = DATASET_DIR / rel
            if not sample_dir.is_dir():
                raise FileNotFoundError(f"样本目录不存在：{sample_dir}")
            skill_md = _find_skill_md(sample_dir)
            text = _read_truncated(skill_md) if skill_md else ""
            rows.append({
                "sample_id": f"{registry}/{skill_name}",
                "label": label,
                "registry": registry,
                "skill_name": skill_name,
                "skill_md_path": str(skill_md) if skill_md else None,
                "skill_md_text": text,
            })
    return rows


def filter_ids(rows: Iterable[dict], ids: set[str]) -> list[dict]:
    return [r for r in rows if r["sample_id"] in ids]


if __name__ == "__main__":
    rows = load_all()
    n_mal = sum(1 for r in rows if r["label"] == "malicious")
    n_ben = sum(1 for r in rows if r["label"] == "benign")
    n_empty = sum(1 for r in rows if not r["skill_md_text"])
    print(f"总样本数={len(rows)}  恶意={n_mal}  良性={n_ben}  SKILL.md为空={n_empty}")
