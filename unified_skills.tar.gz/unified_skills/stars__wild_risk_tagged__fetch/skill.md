---
author: unknown
name: fetch
permissions: []
provenance: unverified
risk_tags:
- system_access
tool_deps: []
---
# MCP Fetch Skill

This skill allows the Agent to use a Python script to call the Model Context Protocol (MCP) fetch server to retrieve webpage content. It is especially suitable for obtaining webpage content and providing it as context to AI.

## Core Features

- **Automated Fetching**: Automatically starts and connects to the `@smithery/mcp-fetch` server.
- **Content Extraction**: Can retrieve text content from a specified URL.
- **No Additional Python Dependencies Required**: Implemented using the Python standard library, with no need to install extra pip packages (only `node/npx` and `python` need to be installed in the system environment).

## Usage Instructions

1.  **Determine the Target URL**: Identify the webpage URL whose content the user needs.
2.  **Run the Script**: In the project root directory, run the following command in the terminal:
    ```bash
    python fetch/fetch.py "https://example.com"
    ```
3.  **Process the Output**: The script will print the webpage content text directly to standard output.

## Technical Details

- **Communication Protocol**: Uses JSON-RPC 2.0 to communicate with the MCP server via standard input/output (stdio).
- **Server Startup**: Uses `npx -y @smithery/mcp-fetch` to start the server.
- **Initialization Process**: The script sends an `initialize` request and handles the `notifications/initialized` notification to establish an MCP-compliant connection.
- **Tool Invocation**: Calls the `fetch` tool via the `tools/call` method, supporting the `maxLength` and `raw` parameters (the script uses `maxLength: 20000` by default).