---
author: unknown
name: zhipu-search
permissions: []
provenance: unverified
risk_tags:
- system_access
tool_deps: []
---
# zhipu-search

## Instructions
1. Put all temporary programs, files, and code generated during execution into the output/ directory under the current project root.
4. Based on the user's provided search key phrase {original}, first perform an analysis. If it contains time-related search conditions, such as today, yesterday, tomorrow, the day after tomorrow, next week, etc., first obtain the current date and calculate the exact date based on the current date, then use the calculated date to construct a new search query {modify}.
5. Call zhipu's search engine to search {modify}, obtain the search results, and provide source information and URL.
```
cd .claude/skills/zhipu-search && uv run zhipu_searcher.py "your question"
```