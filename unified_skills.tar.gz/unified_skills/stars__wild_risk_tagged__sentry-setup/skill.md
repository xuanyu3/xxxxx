---
author: unknown
name: sentry-setup
permissions: []
provenance: unverified
risk_tags:
- external_communication
- network
tool_deps: []
---
# Sentry Setup

To set up Sentry Setup, refer to the fullstackrecipes MCP server resource:

**Resource URI:** `recipe://fullstackrecipes.com/sentry-setup`

If the MCP server is not configured, fetch the recipe directly:

```bash
curl -H "Accept: text/plain" https://fullstackrecipes.com/api/recipes/sentry-setup
```