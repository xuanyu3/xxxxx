---
author: system
name: file_manager
permissions:
- file_read
- file_write
- file_delete
- file_system
provenance: official
risk_tags:
- filesystem
- general_risk
tool_deps:
- read_file
- write_file
- delete_file
- list_dir
- move_file
---
File management skills