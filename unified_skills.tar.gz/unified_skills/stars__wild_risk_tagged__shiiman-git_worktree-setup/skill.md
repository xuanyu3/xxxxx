---
author: unknown
name: shiiman-git:worktree-setup
permissions: []
provenance: unverified
risk_tags:
- data_deletion
- system_access
tool_deps: []
---
# Worktree Setup

gtr (git-worktree-runner) installation check and .gtrconfig generation/update skill.
Each time it runs, it updates .gtrconfig to match the current state of the project.

## Help

If `$ARGUMENTS` contains `--help`, display the following and exit:

```text
/shiiman-git:worktree-setup - Worktree Setup

Overview:
  Check gtr installation and generate/update .gtrconfig.
  Each time it runs, it updates .gtrconfig to match the current state of the project.

Usage:
  /shiiman-git:worktree-setup [options]

Options:
  --help  Show this help
```

## Execution Flow

### Step 1: Check gtr installation

```bash
git gtr --version
```

**If not installed**:

Provide installation instructions and end processing.

```
gtr is not installed. Please install it using the following steps:

## Installation

# Homebrew (recommended)
brew install coderabbitai/gtr/git-gtr

# Or manual installation
git clone https://github.com/coderabbitai/git-worktree-runner.git
cd git-worktree-runner
sudo ln -s "$(pwd)/bin/git-gtr" /usr/local/bin/git-gtr

# Verify
git gtr --version
```

### Step 2: Analyze project state

Automatically detect the project type from package files.

```bash
# Node.js
[ -f "package.json" ] && PROJECT_TYPE="nodejs"

# Python
[ -f "pyproject.toml" ] || [ -f "requirements.txt" ] && PROJECT_TYPE="python"

# Go
[ -f "go.mod" ] && PROJECT_TYPE="go"

# Rust
[ -f "Cargo.toml" ] && PROJECT_TYPE="rust"

# PHP
[ -f "composer.json" ] && PROJECT_TYPE="php"

# Other
PROJECT_TYPE="generic"
```

If an existing .gtrconfig is present, load it:

```bash
cat .gtrconfig 2>/dev/null
```

### Step 3: Generate/update .gtrconfig

Generate based on a template appropriate for the project type.
If existing settings are present, show the diff and ask the user to confirm.

#### Node.js project

```ini
[copy]
  include = **/.env.example
  include = **/.nvmrc
  include = **/tsconfig.json
  include = **/.prettierrc
  include = **/.eslintrc*
  exclude = **/.env
  exclude = **/.env.local
  excludeDirs = node_modules
  excludeDirs = dist
  excludeDirs = .next
  excludeDirs = build

[hooks]
  postCreate = npm install

[defaults]
  editor = cursor
  ai = claude
```

#### Python project

```ini
[copy]
  include = **/.env.example
  include = **/pyproject.toml
  include = **/requirements*.txt
  include = **/.python-version
  exclude = **/.env
  exclude = **/.env.local
  excludeDirs = .venv
  excludeDirs = venv
  excludeDirs = __pycache__
  excludeDirs = .mypy_cache
  excludeDirs = .pytest_cache
  excludeDirs = *.egg-info

[hooks]
  postCreate = pip install -e ".[dev]"

[defaults]
  editor = cursor
  ai = claude
```

#### Go project

```ini
[copy]
  include = **/.env.example
  include = **/go.mod
  include = **/go.sum
  exclude = **/.env
  exclude = **/.env.local
  excludeDirs = vendor
  excludeDirs = bin

[hooks]
  postCreate = go mod download

[defaults]
  editor = cursor
  ai = claude
```

#### Rust project

```ini
[copy]
  include = **/.env.example
  include = **/Cargo.toml
  include = **/Cargo.lock
  exclude = **/.env
  exclude = **/.env.local
  excludeDirs = target
  excludeDirs = .cargo

[hooks]
  postCreate = cargo fetch

[defaults]
  editor = cursor
  ai = claude
```

#### PHP project

```ini
[copy]
  include = **/.env.example
  include = **/composer.json
  include = **/composer.lock
  exclude = **/.env
  exclude = **/.env.local
  excludeDirs = vendor

[hooks]
  postCreate = composer install

[defaults]
  editor = cursor
  ai = claude
```

#### Generic project

```ini
[copy]
  include = **/.env.example
  exclude = **/.env
  exclude = **/.env.local

[hooks]
  postCreate = echo "Worktree created successfully"

[defaults]
  editor = cursor
  ai = claude
```

### Step 4: Write file

For the first run, generate it directly.
If an existing file is present, create a backup, show the diff, and update only after user confirmation.

```bash
# Backup (if an existing file is present)
[ -f .gtrconfig ] && cp .gtrconfig .gtrconfig.backup
```

### Step 5: Completion report

```
## .gtrconfig has been updated

Project type: {PROJECT_TYPE}

{diff of changes or generated content}

### Next step

- Create a worktree: `/shiiman-git:worktree`
```

## Details of .gtrconfig settings

### [copy] section

Defines rules for files to copy when creating a worktree.

| Setting item  | Description                  | Example               |
| ------------- | ---------------------------- | --------------------- |
| `include`     | Glob patterns to copy        | `**/.env.example`     |
| `exclude`     | Glob patterns to exclude     | `**/.env`             |
| `includeDirs` | Directories to copy          | `node_modules`        |
| `excludeDirs` | Directories to exclude       | `node_modules/.cache` |

### [hooks] section

Defines commands to run automatically during the worktree lifecycle.

| Hook name    | Description                         | Example              |
| ------------ | ----------------------------------- | -------------------- |
| `postCreate` | After worktree creation             | `npm install`        |
| `preRemove`  | Before worktree removal (abort on failure) | `npm run clean`  |
| `postRemove` | After worktree removal              | `echo "removed"`    |

### [defaults] section

Defines the default editor and AI tool.

| Setting item | Description            | Example                      |
| ------------ | ---------------------- | ----------------------- |
| `editor` | Default editor   | `cursor`, `code`, `vim` |
| `ai`     | Default AI tool | `claude`, `other`       |

## Important notes

- ✅ Safe to run multiple times (idempotent)
- ✅ If existing settings are present, show the diff and confirm
- ✅ Automatically create a backup
- ❌ Do not overwrite existing settings without user confirmation

## Related resources

- Official gtr repository: https://github.com/coderabbitai/git-worktree-runner
- Related skill: `worktree` - manage worktrees with gtr