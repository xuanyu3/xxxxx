---
author: unknown
name: neon-drizzle-setup
permissions: []
provenance: unverified
risk_tags:
- external_communication
- network
tool_deps: []
---
# Neon + Drizzle Setup

To set up Neon + Drizzle Setup, refer to the fullstackrecipes MCP server resource:

**Resource URI:** `recipe://fullstackrecipes.com/neon-drizzle-setup`

If the MCP server is not configured, fetch the recipe directly:

```bash
curl -H "Accept: text/plain" https://fullstackrecipes.com/api/recipes/neon-drizzle-setup
```