---
author: third_party_a
name: email_sender
permissions:
- email
- network
- file_read
provenance: community
risk_tags:
- data_leak
- email
- external_communication
tool_deps:
- send_email
- attach_file
- read_file
---
# Email Sending Skill

Email sending skill: compose and send emails, with attachment support.

## Capabilities

- Compose email body (plain text and HTML)
- Add file attachments
- Send to specified recipients

## Security Constraints

- Maximum of 10 emails sent per hour
- Maximum attachment size of 25MB
- Sensitive files (.env, .pem, .key) cannot be attached
- User confirmation of recipient address is required before sending