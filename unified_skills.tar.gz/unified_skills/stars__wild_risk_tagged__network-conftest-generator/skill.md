---
author: unknown
name: network-conftest-generator
permissions: []
provenance: unverified
risk_tags:
- data_deletion
- database
- external_communication
- network
tool_deps: []
---
# Network Test Environment Generator

## Objective
Refer to the workflow to create a `Todo List`, and according to the task list, generate the `conftest.py` file. This file is a code file for network device testing backgrounds. It is responsible for test background setup and cleanup, ensuring that all network test cases are executed in a unified network environment and providing a shared mechanism for device resources, topology configuration, and test data.


## Core Resource:: H3C Knowledge Base Retrieval Guide
**Important strategy:** Retrieval must follow the principles of **"iterative loop"** and **"full-library scan"**.

**Available knowledge bases (every retrieval round must cover all of the following libraries):**
6. **design_ke** (user design experience library)
1. **background_ke** (historical background library, conftest.py code repository)
2. **v9_press_example** (common networking configuration library)
3. **example_ke** (test case implementation library)
4. **cmd_ke** (specific command-line/configuration parameter library)
5. **press_config_des** (standardized configuration steps/processes)



**Knowledge base retrieval script:**

Use the following `bash` script to perform retrieval from the specified knowledge bases.
1. **design_ke library retrieval, storing users' historical testing experience, should be prioritized**: time period strategy needs to be configured
   ```bash
   /opt/coder/venvs/comware-test/bin/python {current skill path}/script/data_search_h3c_example.py --description "IGMP snooping query group" --indexname "design_ke"
   ```

2. **background_ke library retrieval, which contains historical background code conftest.py**: building DPI functionality, must be retrieved
   ```bash
   /opt/coder/venvs/comware-test/bin/python {current skill path}/script/data_search_h3c_example.py --description "DPI security test" --indexname "background_ke"
   ```

3. **v9_press_example library retrieval, which contains common networking configurations**: configure the switch to achieve interconnection between multiple subnets
   ```bash
   /opt/coder/venvs/comware-test/bin/python {current skill path}/script/data_search_h3c_example.py --description "switch multi-subnet configuration" --indexname "v9_press_example"
   ```

4. **example_ke library retrieval, which contains test case implementation code and some background configuration code**: DHCP relay test case, must be retrieved
   ```bash
   /opt/coder/venvs/comware-test/bin/python {current skill path}/script/data_search_h3c_example.py --description "DHCP relay" --indexname "example_ke"
   ```

5. **cmd_ke library retrieval, used to store network device command lines**: configure interface IP address
   ```bash
   /opt/coder/venvs/comware-test/bin/python {current skill path}/script/data_search_h3c_example.py --description "ip address " --indexname "cmd_ke"

   /opt/coder/venvs/comware-test/bin/python {current skill path}/script/data_search_h3c_example.py --description "configure interface IP address" --indexname "cmd_ke"
   ```

6. **press_config_des library retrieval, storing standardized configuration step descriptions, providing detailed configuration procedures and parameter explanations.**: time period strategy needs to be configured
   ```bash
   /opt/coder/venvs/comware-test/bin/python {current skill path}/script/data_search_h3c_example.py --description "time period configuration" --indexname "press_config_des"
   ```




## Workflow

### Step 1: Initialization Check
Objective: Ensure there is an available baseline `conftest.py` file in the workspace.

1. **Check file**: Use `Ls` to check whether `conftest.py` exists in the current workspace.
2. **Copy if missing**:
   - **If the file does not exist**:
     - Read the template file: `{current skill path}/templates/conftest.py`.
     - Use the cp command to copy this file into the current workspace.
     - *(At this point, `conftest.py` is ensured to exist in the workspace, continue to Step 2)*
   - **If the file already exists**:
     - Directly proceed to Step 2.

### Step 2: Deep Validation and Iterative Knowledge Retrieval
Objective: **This is the most critical step**. Through **multiple rounds of iterative retrieval, with every round traversing all databases**, and by dynamically adjusting retrieval terms in a loop, fully understand the business background from macro to micro, and deeply comprehend the business from multiple dimensions (background + commands + steps), comparing the "current conftest.py file capability" with the "user's actual requirements".

**Strict prohibitions:**
- **Do not** decide all retrieval rounds in advance before retrieval begins (for example: "I plan to search BGP in round 1 and neighbors in round 2..."). This is wrong!
- **Must** complete one round of retrieval, **read and analyze** the returned content, and only then decide what to search next.

**Required actions**
- **Todo List**: After each round of retrieval, you must **update the Todo List, but do not delete Step 4 validation**.


1. **Read current state**
   - Read the full content of `conftest.py` in the current workspace.
   - Read the topology file (usually a .topox) to obtain the physical device list (such as DUT1, DUT2) and understand the links between devices.
2. **Dynamic retrieval loop (The Dynamic Loop)**:
   Please strictly follow the algorithm below until the business logic is completely clear:

   - **Initial seed**:
     - Extract the core noun from the user input (for example, if the user input is "BGP add-path", the initial term is "BGP add-path").

   - **Execute loop (Start Loop)**:
     1. **Full-library scan (Action)**:
        - Use the current "keyword" and **continuously execute 5 retrieval commands** to traverse all 5 databases.
     
     2. **Result analysis (Observation)**:
        - Carefully read the returned content from the 5 libraries.
        - **Look for the "unknown knowns"**: pay attention to **new terms** that appear in the returned results but whose specific configuration methods you do not yet know.
          - *Example*: You searched for "BGP", and the results mentioned that "Route-Reflector needs to be configured to take effect." At this point, "Route-Reflector" is the new blind spot exposed by the retrieval results.

     3. **Decision making (Decision)**:
        - Ask yourself: Have I mastered every specific command line, parameter value, and configuration order needed to complete the user's requirement?
        - **YES** -> Exit the loop and proceed to Step 3.
        - **NO** -> **Update the keyword**.
          - **Key rule**: The new keyword must come **directly from the results of the previous round**, not from the user's original input.
          - *Example*: The next keyword should be adjusted to "configure BGP Route-Reflector commands" instead of continuing to search for "BGP".
     
     4. **Return to the first step**: Use the new keyword to perform the full-library scan again.

3. **Requirement comparison**:
   - Based on a complete understanding of the business background, analyze the user's specific testing requirements,
   - Check whether the current code content already contains the logic required by the user.
   - *Note: If it is a freshly copied default template, it is usually judged as "non-compliant" due to missing specific configurations (such as only a single device).*

### Step 3: Decision and Execution
Execute according to the comparison result in Step 2:

#### Case A: Content does not match (Mismatch)
1.  **Make a plan (Todo List)**:
    - Briefly describe the modification plan to the user.
2.  **Refactor code and fill gaps**:
    - When writing specific code lines, if you find that the retrieval in Step 2 still has omissions, you **must trigger a full-library scan again**.
    - For each item in the Todo List, ensure there is a clear database retrieval result as support, **do not fabricate configurations, and do not delete Step 4**.
3. **Overwrite write**: Use `Edit` to write the updated code into `conftest.py`.
4. **Feedback**: Reply "After comprehensive search and reference of the H3C knowledge base, updated with deep understanding of the business context `conftest.py`。"
    

#### Case B: Content matches (Match)
1. **Action**: Do not make any modifications.
2. **Feedback**: Reply "现有 `conftest.py` 已符合需求，无需修改。"。

### Step 4: Validation
Validate the final `conftest.py` file to avoid the following errors.

1. **Full coverage verification**: Confirm whether in each round of retrieval, **no database was omitted**? (Even if you think a certain library may be useless, you must still check it just in case.)
2. **Keyword evolution**: Confirm whether the retrieval terms in the next round were optimized based on the learning from the previous round?
3. **Deep understanding**: Before starting to write code, have you fully understood this feature like an H3C network expert?
4. The `conftest.py` file does not need to use `CheckCommand()` or `assert()` and other functions to verify configuration results.
5. Do not use device names or ports that do not exist in topox; pay attention to case sensitivity and existence.
   For example, in the following topology, the device name is dut1 and the port name is port1.
   ```xml
      <LINK_LIST>
      <LINK>
         <NODE>
         <DEVICE>dut1</DEVICE>
         <PORT>
            <NAME>port1</NAME>
            <TYPE/>
            <IPAddr/>
            <IPv6Addr/>
            <SLOT_TYPE/>
            <TAG/>
         </PORT>
         </NODE>
         <NODE>
         <DEVICE>PC</DEVICE>
         <PORT>
            <NAME>port1</NAME>
            <TYPE/>
            <IPAddr/>
            <IPv6Addr/>
            <SLOT_TYPE/>
            <TAG/>
         </PORT>
         </NODE>
      </LINK>
   </LINK_LIST>
   ```
  。
6. Do not use atf_check and atf_assert; this kind of method is illegal. For H3C device-related checks, only CheckCommand may be used, for example:
   ```python
   gl.DUT.CheckCommand('Check port information, expected link state UP, IP address correct', 
                  cmd=f'display interface Ethernet0/1',
         expect=['Line protocol current state: UP', 'Internet Address is 11.91.255.79/24'],
         is_strict=True, 
                  relationship='and',
         stop_max_attempt=3, wait_fixed=2)
   ```
7. Interface usage notes:
   - Port IPv4 address mask:    gl.dut.port1.mask
   - Port IPv4 address host mask:  gl.dut.port1.hostmask
   - Port IPv6 address:         gl.dut.port1.ip6
   - Port IPv6 address mask:     gl.dut.port1.mask6
   - Port IPv6 address mask length: gl.dut.port1.masklen6
   - atf_logs(f'script_log', 'info')   -----  only supports info warn error three levels
   - Wait time:  atf_wait('wait_reason_description', 5)   ----  unit is seconds