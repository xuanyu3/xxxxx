---
author: unknown
name: shiki-code-blocks
permissions: []
provenance: unverified
risk_tags:
- external_communication
- network
tool_deps: []
---
# Shiki Code Blocks

To set up Shiki Code Blocks, refer to the fullstackrecipes MCP server resource:

**Resource URI:** `recipe://fullstackrecipes.com/shiki-code-blocks`

If the MCP server is not configured, fetch the recipe directly:

```bash
curl -H "Accept: text/plain" https://fullstackrecipes.com/api/recipes/shiki-code-blocks
```