---
author: system
name: web_search
permissions:
- network
provenance: official
risk_tags:
- general_risk
- network
tool_deps:
- search_engine
- fetch_url
---
Web search skills