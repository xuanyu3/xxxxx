---
author: unknown
name: skill-quality-validator
permissions: []
provenance: unverified
risk_tags:
- data_deletion
tool_deps: []
---
# Skill Quality Validator - Skill Quality Checker

Claude skill quality checker, automatically validates skill quality based on the official creation process specification.

## Quick Start

### Basic Usage

1. **Prepare the skill to be checked**
   - Skill directory path (e.g. `/mnt/skills/user/my-skill`)
   - Or a packaged .skill file

2. **Run the check**
   ```bash
   python scripts/check_skill.py <skill path>
   ```

3. **View the report**
   - Overall score (0-100 points)
   - Issue list (critical/warning/suggestion)
   - Specific improvement suggestions

### Supported Input Types

| Input Type | Example | Description |
|---------|------|------|
| Skill directory | `/mnt/skills/user/my-skill` | Local skill directory |
| .skill file | `/home/claude/my-skill.skill` | Packaged skill file |
| Relative path | `./my-skill` | Skill in the current directory |
| Absolute path | `/home/claude/skill-folder` | Skill at any location |

## Check Content

### Comprehensive Quality Check

The checker validates the following 7 dimensions:

1. **Structural Integrity** (30 points)
   - Existence of required files
   - Directory structure compliance
   - Cleanup of example files

2. **YAML Compliance** (20 points)
   - Frontmatter format
   - Completeness of required fields
   - Field content compliance

3. **Description Quality** (15 points)
   - "When to use" explanation
   - Number of specific scenarios (3-5)
   - Description length and clarity

4. **Content Quality** (20 points)
   - SKILL.md length control (<500 lines)
   - Reasonable section structure
   - Code block management

5. **Reference Validity** (10 points)
   - Correctness of file references
   - Path existence verification

6. **Code Quality** (5 points)
   - Script syntax correctness
   - Completeness of docstrings
   - Shebang compliance

7. **Documentation Quality**
   - Richness of References content
   - Markdown format compliance

### Scoring Levels

| Score | Grade | Description |
|-----|------|------|
| 90-100 | A - Excellent | Fully meets best practices |
| 80-89 | B - Good | Basically compliant, with a little room for improvement |
| 70-79 | C - Pass | Meets basic requirements, optimization recommended |
| 60-69 | D - Needs Improvement | Has obvious issues |
| 0-59 | F - Fail | Has critical issues |

**Passing Criteria:** Score ≥70 points and no critical issues

## Workflow

### Complete Check Process

```
User requests a check
    ↓
Prepare workspace
- .skill file automatically extracted
- Directory used directly
    ↓
Run 7 checks
- Structure, YAML, description
- Content, references, code, documentation
    ↓
Calculate overall score
- Deduction rule calculation
- Grade assignment
    ↓
Generate detailed report
- Issue classification
- Improvement suggestions
    ↓
Output check results
```

### Issue Classification System

**🔴 Critical Issues (Critical)**
- Prevent the skill from working properly
- Must be fixed immediately
- Each item deducts 10-30 points

**⚠️ Warnings (Warning)**
- Affect skill quality
- Recommended to fix as soon as possible
- Each item deducts 3-10 points

**⭐ Suggestions (Suggestion)**
- Directions for optimization and improvement
- Can be implemented gradually
- No points deducted

## Report Interpretation

### Report Structure

```
============================================================
Skill Quality Check Report
============================================================

Skill Name: my-skill
Overall Score: 85/100
Grade: B - Good
Total Issues: 5
Check Result: ✅ Pass

============================================================
🔴 Critical Issues (Critical Issues)
============================================================

1. Missing required file: SKILL.md
   💡 Improvement Suggestion: Create the SKILL.md file, which is the core document of the skill

============================================================
⚠️ Warnings (Warnings)
============================================================

1. description is missing a "When to use" explanation
   💡 Improvement Suggestion: Add a "Use when..." or "适用于..." description to indicate trigger scenarios

2. Found 3 example files not cleaned up
   💡 Improvement Suggestion: Delete the following files: scripts/example.py, ...

============================================================
💡 Optimization Suggestions (Suggestions)
============================================================

1. Suggested sections to add: Quick Start, Workflow
   💡 Improvement Suggestion: These sections help users quickly understand how to use the skill
```

### How to Improve

1. **Fix critical issues first**
   - These issues will prevent the skill from running
   - Must be resolved before packaging

2. **Handle warnings**
   - Improve skill quality
   - Enhance user experience

3. **Consider suggestions**
   - Optimization directions
   - Can be implemented in later versions

4. **Recheck**
   - Run the check again after fixing
   - Ensure the passing criteria are met

## Configuration Notes

### Customizing Check Standards

The checker uses fixed scoring standards based on the official best practices documentation. For details on the check items and scoring rules, see:

- **Complete Checklist**: `references/checklist.md`
- **Quick Fix Guide**: `references/quick_fixes.md`

### Modifying Scoring Weights

If you need to adjust the scoring standards (not recommended), you can modify the deduction parameters in `scripts/check_skill.py`:

```python
# Example: adjust the deduction for description missing "When to use"
if not any(keyword in description.lower() for keyword in ...):
    self.score -= 8  # Change to the deduction value you want
```

## Common Use Cases

### Scenario 1: New Skill Development Validation

**Workflow:**
```bash
# 1. Create the skill
python /mnt/skills/examples/skill-creator/scripts/init_skill.py my-skill

# 2. Develop the skill content
# ... write SKILL.md, scripts, references ...

# 3. Quality check
python /mnt/skills/user/skill-quality-validator/scripts/check_skill.py my-skill

# 4. Improve based on the report

# 5. Recheck until it passes
```

### Scenario 2: Existing Skill Update Check

**Workflow:**
```bash
# 1. Modify the skill content
# ... update SKILL.md or add new features ...

# 2. Verify whether the update is compliant
python scripts/check_skill.py /mnt/skills/user/existing-skill

# 3. Ensure the score does not decrease
```

### Scenario 3: Third-Party Skill Evaluation

**Workflow:**
```bash
# 1. Download the skill file
# downloaded-skill.skill

# 2. Quality evaluation
python scripts/check_skill.py downloaded-skill.skill

# 3. View the report to decide whether to use it
```

### Scenario 4: Batch Skill Checking

**Workflow:**
```bash
# Check all user skills
for skill in /mnt/skills/user/*/; do
    echo "Checking: $skill"
    python scripts/check_skill.py "$skill"
    echo "---"
done
```

## Integration with Official Tooling

### Working with package_skill.py

```bash
# Standard skill release process

# 1. Quality check
python /mnt/skills/user/skill-quality-validator/scripts/check_skill.py my-skill
# Ensure it passes (≥70 points, no critical issues)

# 2. Package the skill
python /mnt/skills/examples/skill-creator/scripts/package_skill.py my-skill
# Generate my-skill.skill

# 3. Distribute and use
```

### Continuous Quality Assurance

It is recommended to run checks at the following times:

- ✅ After creating a new skill
- ✅ After major feature updates
- ✅ Before packaging and release
- ✅ Periodic review (e.g. monthly)

## Advanced Usage

### Custom Check Rules

If you need to add checks for specific items, you can extend `scripts/check_skill.py`:

```python
def _check_custom_requirement(self):
    """Custom check item"""
    # Your check logic
    if not meets_requirement:
        self._add_issue('warning', 'Issue description', 'Improvement suggestion')
        self.score -= 5
```

### Integrating into CI/CD

Use in automated workflows:

```yaml
# GitHub Actions example
- name: Validate Skill Quality
  run: |
    python check_skill.py my-skill
    if [ $? -ne 0 ]; then
      echo "Quality check failed"
      exit 1
    fi
```

### Generating Quality Badges

Generate README badges based on the check results:

```markdown
![Quality](https://img.shields.io/badge/quality-85%25-green)
![Grade](https://img.shields.io/badge/grade-B-blue)
```

## Reference Resources

- **Detailed Checklist**: `references/checklist.md` - Complete explanation of all check items
- **Quick Fix Guide**: `references/quick_fixes.md` - Solutions to common issues
- **Official Specification**: Claude skills creation process specification (6-step method) - foundational methodology

## Troubleshooting

### Problem: The check script reports an error

```bash
# Make sure Python 3 is available
python3 --version

# Make sure you have execute permission
chmod +x scripts/check_skill.py
```

### Problem: .skill file cannot be extracted

```bash
# A .skill file is essentially a zip file
# Manual extraction test
unzip -t skill-file.skill
```

### Problem: The score does not match expectations

- Check the detailed report to understand the reason for point deductions
- Refer to `references/checklist.md` for the scoring rules
- Each issue has a corresponding improvement suggestion

## Limitations

- Does not check whether the skill's actual functionality runs correctly
- Does not verify whether the skill's business logic is reasonable
- Does not check the specific contents of resource files (assets/)
- Only performs static analysis, no dynamic testing

**Recommendation:** After the quality check passes, actual functional testing is still required.

## Skill Changelog

- **v1.0** (2025-12-10)
  - Initial release
  - Supports comprehensive checks across 7 dimensions
  - Provides detailed improvement suggestions
  - Supports .skill file and directory checks