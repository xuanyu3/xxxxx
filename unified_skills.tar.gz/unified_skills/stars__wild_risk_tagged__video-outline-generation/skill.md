---
author: unknown
name: video-outline-generation
permissions: []
provenance: unverified
risk_tags:
- credentials
- data_access
tool_deps: []
---
# Video Outline Generation

## When to Use This Skill
Use this skill when the user has any of the following needs:
- Needs to create a "video outline" or "video script"
- Doing "video planning" or "video content planning"
- Preparing to "make a video" or "create a video"
- Needs "video ideas" or "video direction"
- Wants a "video structure" or "content framework"

## Core Goal
Quickly generate multiple video creation plans based on the user's needs, with each plan including a complete outline structure to help the user get started with video production quickly.

## Execution Process

### Step 1: Needs Analysis and Positioning Confirmation
**Goal**: Clarify the video's objective, audience, and style

**Key Element Analysis**:
1. **Video Objective Positioning**
   - Main purpose: knowledge sharing, entertainment/comedy, product promotion, brand building
   - Success metrics: views, like rate, completion rate, conversion rate
   - Expected outcome: educational inspiration, emotional resonance, commercial conversion

2. **Target Audience Analysis**
   - Age group: teenagers, young adults, middle-aged, elderly
   - Interest preferences: technology, lifestyle, education, entertainment
   - Viewing habits: short videos (1-3 minutes), medium (5-10 minutes), long videos (10+ minutes)
   - Consumption scenarios: fragmented time, study time, leisure time

3. **Content Type Confirmation**
   - Knowledge and education: tutorials, explanations, analysis
   - Lifestyle sharing: vlog, daily life, experiences
   - Product reviews: unboxing, testing, comparisons
   - Entertainment content: comedy, challenges, stories

4. **Resource Constraint Assessment**
   - On-camera willingness: live appearance, voiceover, subtitles only
   - Filming equipment: phone, camera, screen recording
   - Scene limitations: indoor, outdoor, specific environments
   - Production capability: editing, special effects, animation

### Step 2: Multi-Plan Outline Design
**Goal**: Generate 2-3 video plans with different styles

#### Plan 1: [Video Title] - [Plan Type]
**Video Positioning**: [knowledge-sharing / lifestyle-experience / product-review / entertainment-interaction]

**Estimated Duration**: [X minutes]
**Target Completion Rate**: [X%]
**Core Highlights**:
- 🎯 [Main attraction 1]
- 💡 [Innovation point 1]
- 📈 [Distribution advantage 1]

**Thumbnail Design Suggestions**:
- **Main Element**: [the main content of the image]
- **Text Design**: [how to handle the title text]
- **Color Scheme**: [primary tone and palette]
- **Expression/Action**: [suggested facial expression or action]
- **Composition Style**: [overall composition and visual style]

**Video Outline Structure**:

```
🎬 Opening (0-15 seconds) - Golden Hook
├── Suspense Introduction: [how to grab attention in the first 3 seconds]
├── Value Promise: [tell the audience what they will gain]
└── Persona Building: [build an emotional connection with the audience]

📺 Main Body (15 seconds - X minutes) - Core Content
├── Part One: [main content and structure]
│   ├── Key Point 1: [specific content]
│   ├── Key Point 2: [specific content]
│   └── Key Point 3: [specific content]
├── Part Two: [progressive content]
│   ├── In-depth Analysis: [detailed explanation]
│   ├── Practical Demo: [operation or display]
│   └── Results Display: [results or feedback]
└── Part Three: [elevated content]
    ├── Summary of Key Points: [summarize the highlights]
    ├── Extended Thinking: [inspire the audience]
    └── Practical Advice: [actionable suggestions]

🎭 Ending (last 15 seconds) - Interactive Wrap-up
├── Value Recap: [restate the core value]
├── Interaction Prompt: [likes, comments, follows]
└── Next Episode Preview: [build anticipation]
```

**Filming and Production Notes**:
- **Scene Setup**: [suggestions for background and environment]
- **Equipment Requirements**: [filming equipment and technical requirements]
- **Performance Guidance**: [presentation tips when on camera]
- **Editing Focus**: [key points in post-production]

**Advantages Analysis**:
- ✅ [Advantage 1: e.g. moderate production difficulty]
- ✅ [Advantage 2: e.g. strong content value]
- ✅ [Advantage 3: e.g. easy to spread]

**Challenge Estimate**:
- ⚠️ [Challenge 1: e.g. requires specific equipment]
- ⚠️ [Challenge 2: e.g. relatively high performance difficulty]
- ⚠️ [Challenge 3: e.g. strong subject-matter expertise]

### Step 3: Detailed Content Filling
**Goal**: Provide detailed content suggestions for each outline section

**Content Filling Key Points**:

#### Detailed Opening Design
```
3-second hook examples:
- Suspense type: "I discovered a secret that shocked me..."
- Data type: "90% of people don't know this trick..."
- Result type: "I achieved this in 10 days..."
- Emotional type: "At that moment, I really cried..."

15-second value promise:
- Clearly tell the audience what they will get
- Quantify value with specific numbers
- Create urgency and scarcity
```

#### Detailed Main Body Design
```
Content organization methods:
1. Problem-solution structure
   - Raise a common problem
   - Analyze the cause of the problem
   - Provide a solution
   - Show implementation results

2. Chronological structure
   - Past state
   - Turning point event
   - The process of change
   - Current results

3. Comparative analysis structure
   - Wrong approach
   - Correct approach
   - Effect comparison
   - Selection advice
```

#### Detailed Ending Design
```
Interactive prompts:
- "What do you think? Tell me in the comments~"
- "Like and save it so you don't get lost next time!"
- "Follow me for daily useful content"
- "What do you want to see next? Tell me in the comments!"

CTA design:
- Clear action instructions
- Low action barrier
- Immediate action incentive
```

### Step 4: Multi-Dimensional Comparison and Recommendation
**Goal**: Help the user choose the most suitable plan

**Comparison Dimensions**:
1. **Production Difficulty**: equipment requirements, skill requirements, time investment
2. **Content Value**: practicality, uniqueness, professionalism
3. **Distribution Potential**: topicality, shareability, spreadability
4. **Personal Fit**: interest match, ability match, resource match

**Recommendation Logic**:
```
If you are a [beginner / experienced / professional creator], I recommend [Plan X]
because [production difficulty / content value / distribution potential] suits you better.

If you want to [get started quickly / create high-quality work / pursue traffic], I recommend [Plan Y]
because it has advantages in [production cost / content quality / distribution effect].
```

## Special Scenario Handling

### 1. Zero-Experience Creators
**Recommended Strategy**:
- Prioritize plans that are simple to operate and low-cost
- Choose content that does not require on-camera appearance or has low performance demands
- Provide detailed production guidance and tips

### 2. Pursuing High-Quality Content
**Recommended Strategy**:
- Recommend plans that require certain equipment and technical skills
- Focus on the professionalism and depth of the content
- Provide high-quality production standards

### 3. Commercial Promotion Needs
**Recommended Strategy**:
- Recommend product review or experience-based content
- Focus on conversion rate and commercial value
- Balance content quality and business goals

## Quality Standards

### Outline Quality Standards
- [ ] Clear structure and coherent logic
- [ ] Clear content value and practicality
- [ ] Matches platform characteristics and audience preferences
- [ ] Achievable within the user's capabilities

### Creative Quality Standards
- [ ] Attractive title with click appeal
- [ ] Hook in the opening that grabs attention
- [ ] Highlights in the content that resonate
- [ ] Guidance in the ending that encourages interaction

## Delivery Example

### Example: Efficiency Improvement Video Outline

**Need**: Create a video about improving work efficiency

**Generated Plans**:

#### Plan 1: 3 Time Management Tips That Double Your Efficiency
**Estimated Duration**: 8 minutes
**Thumbnail**: Clock + rocket, text "Efficiency Doubled"

**Outline Structure**:
```
Opening (15 seconds):
"You're busy every day, but still feel like nothing gets finished? Today I'm sharing 3 tips that doubled my efficiency!"

Main Body (7 minutes):
1. Pomodoro Technique - Focus for 25 minutes, rest for 5 minutes
2. Time-block Management - Schedule tasks into fixed time slots
3. Buffer Time - Leave 1 hour each day to handle emergencies

Ending (30 seconds):
"Try these methods and tell me which one helps you the most! Like and save, let's improve together!"
```

#### Plan 2: How I Finished a Month's Work in One Week
**Estimated Duration**: 10 minutes
**Thumbnail**: Comparison image "1 week vs 1 month", surprised expression

**Outline Structure**:
```
Opening (20 seconds):
"Last week I only worked 5 days, but I completed a month's worth of work. The secret is..."

Main Body (9 minutes):
1. Identify the problem: analyze time black holes
2. Find the method: deep work + batch processing
3. Implementation process: specific operational steps
4. Results verification: data comparison display

Ending (40 seconds):
"Efficiency isn't about being busy; it's about being smart. What's your efficiency secret?"
```

---
*Last updated: 2024*