---
author: unknown
name: ralph-setup
permissions: []
provenance: unverified
risk_tags:
- external_communication
- network
tool_deps: []
---
# Ralph Agent Loop

To set up Ralph Agent Loop, refer to the fullstackrecipes MCP server resource:

**Resource URI:** `recipe://fullstackrecipes.com/ralph-setup`

If the MCP server is not configured, fetch the recipe directly:

```bash
curl -H "Accept: text/plain" https://fullstackrecipes.com/api/recipes/ralph-setup
```