---
author: unknown
name: nanobanana
permissions: []
provenance: unverified
risk_tags:
- credentials
- data_access
tool_deps: []
---
# StudioJinsei Nanobanana Image Generation Skill

## Overview

This is a Nanobanana Skill for generating StudioJinsei brand visuals.
It directly uses the Google Gemini API to generate logos, Kotone-chan, site visuals, and more.

---

## 📋 Available Models

| Model Name | API Name | Features | Estimated Cost |
|---------|-------|------|----------|
| **Gemini 3 Pro Image** | gemini-3-pro-image-preview | High quality, high resolution | About 21-30 yen/image |
| Gemini 2.5 Flash Image | gemini-2.5-flash-image | Fast, low cost | About 6 yen/image |

**Recommended:** Use **Gemini 3 Pro Image** for StudioJinsei logos and main visuals

---

## 🔧 Prerequisites

### Required
- Google API Key (`GOOGLE_API_KEY`)
- Python 3.x
- google-generativeai package

### Environment Variables
```bash
export GOOGLE_API_KEY="AIzaSyBs2FQS6FYWwx9LKQdyywkBFTEXt5tK9Z8"
```

---

## ⚙️ Setup Steps

### 1. Set the environment variable

#### For macOS/Linux (zsh)
```bash
# Edit ~/.zshrc
nano ~/.zshrc

# Add the following
export GOOGLE_API_KEY="AIzaSyBs2FQS6FYWwx9LKQdyywkBFTEXt5tK9Z8"

# Apply the settings
source ~/.zshrc

# Verify
echo $GOOGLE_API_KEY
```

### 2. Install the Python package

```bash
pip install google-generativeai
```

---

## 🚀 Basic Usage

### Image Generation Script (Simple Version)

```python
import google.generativeai as genai
import os
from pathlib import Path

# API settings
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

# Model selection
model = genai.GenerativeModel("gemini-3-pro-image-preview")  # or "gemini-2.5-flash-image"

# Prompt
prompt = """
[Write the prompt here]
"""

# Generate image
response = model.generate_content(prompt)

# Save
output_path = Path("images/studiojinsei/output.png")
output_path.parent.mkdir(parents=True, exist_ok=True)

if response.candidates and response.candidates[0].content.parts:
    image_data = response.candidates[0].content.parts[0].inline_data.data
    output_path.write_bytes(image_data)
    print(f"Image saved: {output_path}")
```

---

## 📝 How to Create Prompts

### Basic Template

Include the following in every prompt:

```
[StudioJinsei Brand Foundation]

Concept: "Making invisible thoughts visible and tangible"
Tagline: "A studio that creates the spark that turns thoughts into action"

Visual direction:
- Simple yet warm (not cold)
- Organized yet approachable (not rigid)
- Sophisticated yet friendly (not intimidating)
- Professional yet personal (not distant)

Color palette: Soft mint green (#A8D5BA), dark teal (#1D4E4A), pale mint (#E8F5EE), white (#FFFFFF).
Main: soft mint green (#A8D5BA), accent: dark teal (#1D4E4A).

Typography: Modern sans-serif, Poppins or similar clean font style.

Design style:
- Minimalist, Apple-inspired clean aesthetic
- Plenty of white space, generous breathing room
- Simple, uncluttered, focused layout
- High quality, attention to detail

Avoid:
- Flashy, overly colorful, hyper-energetic styles
- Spiritual, abstract, mystical vibes
- Cold, corporate, distant aesthetics
- Cheap, low-quality appearance

---

[Specific instructions here]
```

---

## 🎯 Generation Patterns

### Pattern 1: Logo Generation

**Prompt Example:**
```
[StudioJinsei Brand Foundation]
...

Professional wordmark logo for "StudioJinsei".
Text-only design, no symbols or icons.
Typography: Modern sans-serif, Poppins or similar clean font.
"Studio" in light/thin weight, "Jinsei" in medium/semibold weight.
Color scheme: Dark teal (#1D4E4A) for main text, soft mint green (#A8D5BA) subtle accent.
Minimalist, sophisticated, professional yet approachable.
Clean letterforms with generous letter spacing.
Plenty of white space around the text.
High quality vector style.
```

**Reference:** [brand-foundation.md](./brand-foundation.md)

### Pattern 2: Kotone-chan Generation

**Prompt Example:**
```
[StudioJinsei Brand Foundation]
...

A soft, hand-drawn style illustration of Kotone-chan.
Young Japanese woman with dark long hair.
Mint green bucket hat with subtle leaf pattern.
White elegant clothing.
Gentle, warm illustration style with soft lines.
Muted, sophisticated color palette (soft mint #A8D5BA, dark teal #1D4E4A).
Calm, professional, trustworthy expression with a gentle smile.
Minimal background, plenty of white space.
Apple-inspired clean aesthetic.
She embodies "making invisible thoughts visible" concept.
```

**Reference:** [kotone-character.md](./kotone-character.md)

### Pattern 3: Site Visual Generation

**Prompt Example:**
```
[StudioJinsei Brand Foundation]
...

Website hero section design for StudioJinsei.
Main headline: "A studio that creates the spark that turns thoughts into action"
Subheadline: "Giving visible form to invisible feelings"
Background: Soft mint green gradient (#E8F5EE to #FFFFFF).
Minimalist hand-drawn style illustration of Kotone-chan (optional).
Plenty of breathing room, clean and uncluttered.
Professional yet friendly, modern and sophisticated.
```

---

## 📐 Resolution Settings

The Gemini API does not allow direct resolution specification, but you can request it in the prompt:

```
Generate a 1024x1024 square image.
High resolution, suitable for professional use.
```

Or

```
Generate a 1920x1080 (16:9) landscape image.
```

---

## 💰 Estimated Costs

### API Pricing
| Resolution Equivalent | Cost per Image |
|----------|----------------|
| 1K (1024x1024) | About 21 yen |
| 2K (2048x2048) | About 42 yen |
| 4K (4096x4096) | About 85 yen |

### Production Example
**Logo Production:**
- Generate 3 patterns = About 63 yen
- Final high-resolution version = About 85 yen
- **Total: About 150 yen**

---

## 📋 Checklist

Always confirm the following when generating:

- [ ] Have you referred to [brand-foundation.md](./brand-foundation.md)?
- [ ] Is the color palette (#A8D5BA, #1D4E4A) correct?
- [ ] Does it express "simple, but not cold"?
- [ ] Is there plenty of whitespace?
- [ ] Does it convey StudioJinsei's core concept?
- [ ] Does it avoid no-go designs (sparkly, spiritual, cold, cheap)?

---

## 🖼️ Reference Images

### Image Location

This directory (`nanobanana-base`) includes reference images:

```
nanobanana-base/
└── images/
    └── reference/
        ├── line-profile.jpg        # LINE profile image
        └── officialprofile.PNG     # Official profile image
```

### Using with Claude Skills

When using Claude Skills (`.claude/skills/kotone-*`) in a new repository:

1. **Copy the images into the skill directory**
   ```bash
   mkdir -p .claude/skills/kotone-business/images
   cp manuals/nanobanana/nanobanana-base/images/reference/* .claude/skills/kotone-business/images/
   ```

2. **Reference them in SKILL.md**
   ```markdown
   ## Reference Images
   
   | Purpose | Path |
   |------|------|
   | LINE profile image | `images/line-profile.jpg` |
   | Official profile image | `images/officialprofile.PNG` |
   ```

For details, see the "Place reference images in Claude Skills" section in [setup-guide.md](./setup-guide.md).

---

## 🔗 Related Materials

- [Brand-wide Design Foundation](./brand-foundation.md)
- [Kotone-chan Settings](./kotone-character.md)
- [Setup Guide](./setup-guide.md)
- [Usage Guide](./usage-guide.md)
- [README](./README.md)

---

## 🤖 For AI: Automatic Setup Steps When Requesting Image Production

When a user requests "I want to create an image of XX," automatically perform the following steps:

### 1. Create the project directory

```bash
# Example: for logo production
mkdir -p logo-generation
cd logo-generation
```

### 2. Copy nanobanana-base

```bash
# Copy from the current repository (if already cloned)
cp -r ../nanobanana-base .

# Or clone the repository to obtain it
git clone https://github.com/StudioJinsei/opening-preparation temp
cp -r temp/manuals/nanobanana/nanobanana-base .
rm -rf temp
```

### 3. Set up the Claude Skill

```bash
# Create the skill directory
mkdir -p .claude/skills/nanobanana

# Copy the contents of nanobanana-base (from manuals)
cp -r nanobanana-base/* .claude/skills/nanobanana/
# Or obtain directly from the repository
git clone https://github.com/StudioJinsei/opening-preparation temp
cp -r temp/manuals/nanobanana/nanobanana-base/* .claude/skills/nanobanana/
rm -rf temp

# Check the name in SKILL.md (make sure it is nanobanana)
```

### 4. Create a dedicated prompt file

Create a dedicated prompt file in the project directory (the same directory as `nanobanana-base`) according to the intended use:

```bash
# Example: for logo production
nano logo_prompt.txt
```

**Prompt file structure:**
1. Refer to the "Nanobanana Common Prompt Foundation" in `nanobanana-base/brand-foundation.md`
2. Add specific instructions according to the intended use
3. Name the file according to the use case (e.g., `logo_prompt.txt`, `kotone_prompt.txt`)

### 5. Create a generation script if needed

```python
# Example: generate_logo.py
import google.generativeai as genai
import os
from pathlib import Path

genai.configure(api_key=os.environ["GOOGLE_API_KEY"])
model = genai.GenerativeModel("gemini-3-pro-image-preview")

# Load the base prompt (nanobanana-base has already been copied into the project directory)
with open("nanobanana-base/brand-foundation.md", "r") as f:
    base_content = f.read()
# Extract the common prompt foundation (implementation omitted)

# Load the dedicated prompt
with open("logo_prompt.txt", "r") as f:
    custom_prompt = f.read()

# Combine and generate
prompt = base_prompt + "\n\n---\n\n" + custom_prompt
response = model.generate_content(prompt)
# Save process...
```

### 6. Create README.md (recommended)

Document the project directory structure and usage:

```markdown
# [Project Name]

## Structure
- nanobanana-base/ - Base directory
- [prompt file name] - Dedicated prompt
- [generation script name] - Generation script

## Usage
[Specific usage]
```

### Important Points

- **Save the dedicated prompt file in the same directory as `nanobanana-base` (inside the project directory)**
- Automatically load the base prompt from `nanobanana-base/brand-foundation.md`
- Write only use-case-specific instructions in the dedicated prompt
- Make the project directory self-contained and independent

---

## 🎓 Tips

### Prompt Writing Tips
1. Always include the common prompt foundation
2. Specify color codes (#A8D5BA, #1D4E4A)
3. Clearly state what to avoid (Avoid:)
4. Be specific and avoid vague expressions

### Quality Control
1. Always check the checklist after generation
2. Save prompts and manage versions
3. Generate multiple patterns and compare them

---

**Last updated: 2025/12/20**